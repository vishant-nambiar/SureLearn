const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');
const helmet = require('helmet');
const compression = require('compression');
const MongoDBStore = require('connect-mongodb-session')(session);

const app = express();
const MONGODB_URI = 'mongodb+srv://ayush:ayush@cluster0-bt9rv.mongodb.net/quizTest?retryWrites=true&w=majority';

const store = new MongoDBStore({
    uri: MONGODB_URI,
    collection: 'sessions'
});


const userRoutes = require('./routes/user');

app.set('view engine', 'ejs');
app.set('views')

app.use(helmet());
app.use(compression());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(
    session({
        secret: 'my secret',
        resave: false,
        saveUninitialized: false,
        store: store
    })
);

app.use(userRoutes);

mongoose.connect(MONGODB_URI, { useCreateIndex: true, useNewUrlParser: true, useUnifiedTopology: true }).then(result => {
    app.listen(process.env.PORT || 3000)
}).catch(err => { console.log(err) })