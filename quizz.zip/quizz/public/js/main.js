$(document).ready(function() {
    $(window).keydown(function(event) {
        if (event.keyCode == 116) {
            event.preventDefault();
            return false;
        }
    });
});

let current = 0;

function init() {
    for (let i = 0; i < 30; i++) {
        document.querySelector('#q' + i).style.display = 'none';
    }
    document.querySelector('#previous').style.display = 'none';
    document.querySelector('#submit').style.display = 'none';
}

(function() {
    init();
    show();
}())

let min = 29;
let sec = 59;

setInterval(() => {
    if (min < 10 && sec < 10) {
        document.querySelector('#time').textContent = 'Time Left: 0' + min + ':0' + sec;
    } else if (min < 10) {
        document.querySelector('#time').textContent = 'Time Left: 0' + min + ':' + sec;
    } else if (sec < 10) {
        document.querySelector('#time').textContent = 'Time Left: ' + min + ':0' + sec;
    } else {
        document.querySelector('#time').textContent = 'Time Left: ' + min + ':' + sec;
    }
    if (min === 0 && sec === 0) {
        sub();
    }
    min = (sec == 0) ? min - 1 : min;
    sec = (sec == 0) ? 59 : sec - 1;
    document.querySelector('#time' + current).value = Number(document.querySelector('#time' + current).value) + 1;
}, 1000)


function show() {
    document.querySelector('#q' + current).style.display = 'block';
    if (current !== 0) {
        document.querySelector('#previous').style.display = 'inline';
    }
    if (current !== 29) {
        document.querySelector('#next').style.display = 'inline';
    }
    if (current === 29) {
        document.querySelector('#next').style.display = 'none';
        document.querySelector('#submit').style.display = 'inline';
    }
}

function next() {
    current = current + 1;
    init();
    show();
}

function prev() {
    current = current - 1;
    init();
    show();
}

function sub() {
    let result = true;
    if (min !== 0) {
        result = confirm('Are you sure you want to submit?');
    }
    if (result) {
        document.querySelector('form').submit();
    }
}

document.addEventListener("keydown", (e) => {
    e.preventDefault();
    if ((e.keyCode === 39 || e.key === "ArrowRight" || e.keyCode === 38 || e.key === "ArrowUp") && current !== 29) {
        next();
    }
    if ((e.keyCode === 37 || e.key === "ArrowLeft" || e.keyCode === 40 || e.key === "ArrowDown") && current !== 0) {
        prev();
    }
    if ((e.keyCode === 13 || e.key === "Enter") && current === 29) {
        sub();
    }
    if (e.keyCode === 65 || e.key === 'A' || e.key === 'a' || e.key === "1" || e.keyCode === 97 || e.keyCode === 49) {
        document.getElementById(`q${current}a1`).checked = true;
    }
    if (e.keyCode === 66 || e.key === 'B' || e.key === 'b' || e.key === "2" || e.keyCode === 98 || e.keyCode === 50) {
        document.getElementById(`q${current}a2`).checked = true;
    }
    if (e.keyCode === 67 || e.key === 'C' || e.key === 'c' || e.key === "3" || e.keyCode === 99 || e.keyCode === 51) {
        document.getElementById(`q${current}a3`).checked = true;
    }
    if (e.keyCode === 68 || e.key === 'D' || e.key === 'd' || e.key === "4" || e.keyCode === 100 || e.keyCode === 52) {
        document.getElementById(`q${current}a4`).checked = true;
    }
    if (e.keyCode === 69 || e.key === 'E' || e.key === 'e' || e.key === "5" || e.keyCode === 101 || e.keyCode === 53) {
        document.getElementById(`q${current}a5`).checked = true;
    }
})