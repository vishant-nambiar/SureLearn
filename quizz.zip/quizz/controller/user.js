const bcrypt = require('bcryptjs');
const User = require('../modal/User');

const genral = [{
        section: 'Section1',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section2',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section3',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section4',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section5',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section6',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section7',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section8',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section9',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    },
    {
        section: 'Section10',
        totalAnswered: 0,
        totalCorrect: 0,
        totalIncorrect: 0,
        percent: 0
    }
];

exports.getLogin = (req, res, next) => {
    res.render('login')
}

exports.postLogin = async(req, res, next) => {
    try {
        const user = await User.findOne({ email: req.body.email });
        if (!user) {
            return res.redirect('/login');
        }
        const doMatch = await bcrypt.compare(req.body.password, user.password);
        if (!doMatch) {
            return res.redirect('/login');
        }
        req.session.isLoggedIn = true;
        req.session.user = user;
        return req.session.save(err => {
            return res.redirect('/');
        })
    } catch (err) {
        console.log(err)
    }
}

exports.postRegister = async(req, res, next) => {
    const { email, password, name } = req.body;
    const hashedPassword = await bcrypt.hash(password, 12);
    const user = new User({ name: name, email: email, password: hashedPassword });
    user.genral.push(genral);
    await user.save();
    return res.redirect('/login');
}

exports.getTake = (req, res, next) => {
    res.render('take');
}