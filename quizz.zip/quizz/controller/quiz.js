const Genral = require('../modal/Genral');
const User = require('../modal/User');
const { use } = require('../routes/user');

exports.getQuiz = async(req, res, next) => {
    try {
        const user = await User.findById(req.session.user._id);
        const userData = {
            quizChosen: 'genral',
            sections: user.genral[0]
        };
        const spawn = require("child_process").spawn;
        const process = spawn('python', ["recommendation.py", JSON.stringify(userData.sections), userData.quizChosen]);
        process.stdout.on('data', function(data) {
            const question = JSON.parse(data);
            if (question) {
                res.render('quiz', { questions: question, sub: 'genral' });
            } else {
                res.redirect('/');
            }
        });
    } catch (err) {
        console.log(err);
    }
};

exports.postQuiz = async(req, res, next) => {
    try {
        let total = [];
        const sub = req.body.sub;
        const _id = [req.body['id0'], req.body['id1'], req.body['id2'], req.body['id3'], req.body['id4'], req.body['id5'], req.body['id6'], req.body['id7'], req.body['id8'], req.body['id9'], req.body['id10'], req.body['id11'], req.body['id12'], req.body['id13'], req.body['id14'], req.body['id15'], req.body['id16'], req.body['id17'], req.body['id18'], req.body['id19'], req.body['id20'], req.body['id21'], req.body['id22'], req.body['id23'], req.body['id24'], req.body['id25'], req.body['id26'], req.body['id27'], req.body['id28'], req.body['id29']];
        const original = await Genral.find({ '_id': { $in: _id } });
        let time = 0;
        let score = 0;
        let questions = [];
        let user = await User.findById(req.session.user._id);
        let sections = [...user[sub][0]];
        for (let i = 0; i < 30; i++) {
            let key = original.findIndex(e => e._id.toString() === req.body[`id${i}`]);
            total.push({
                _id: original[key]._id,
                score: (req.body[`answer${i}`] === original[key].Answer) ? 1 : 0,
                time: req.body[`time${i}`],
                userAnswer: req.body[`answer${i}`],
                correctAnswer: original[key].Answer,
                section: original[key].Section,
            });
            questions.push({
                questionId: original[key]._id,
                time: req.body[`time${i}`],
                userChoice: req.body[`answer${i}`]
            });
            time = time + Number(req.body[`time${i}`]);
            score += total[i].score;
            let sectionIndex = user[sub][0].findIndex(e => e.section === original[key].Section);
            sections[sectionIndex].totalAnswered += 1;
            sections[sectionIndex].totalCorrect += (req.body[`answer${i}`] === original[key].Answer) ? 1 : 0;
            sections[sectionIndex].totalIncorrect += (req.body[`answer${i}`] === original[key].Answer) ? 0 : 1;
            sections[sectionIndex].percent = ((sections[sectionIndex].totalCorrect / sections[sectionIndex].totalAnswered) * 100);
            original[key].averageSolvingTime = (((original[key].averageSolvingTime || 0) * original[key].users.userIds.length) + req.body[`time${i}`]) / (original[key].users.userIds.length + 1);
            original[key].users.userIds.push({ userId: req.session.user._id });
            original[key].minimumTime = ((original[key].minimumTime > Number(req.body[`time${i}`])) && (original[key].Answer === req.body[`answer${i}`])) ? Number(req.body[`time${i}`]) : original[key].minimumTime;
            original[key].save();
        }
        user[`${sub}Quizes`].push({
            questions: questions,
            totalCorrect: score,
            time: time,
            subject: 'Genral'
        });
        user[sub] = [];
        user[sub].push(sections);
        user[sub].unshift();
        const user1 = await user.save();
        res.redirect(`/result?id=${user1[`${sub}Quizes`][user1[`${sub}Quizes`].length-1]._id}&sub=${sub}`)
} catch (err) {
    console.log(err);
}
};

exports.getResult = async(req, res, next) => {
    try{
    const {id,sub} = req.query;
    const user = await User.findById(req.session.user._id);
    const quiz = user[`${sub}Quizes`].find(e => e._id.toString() === id.toString());
    if(quiz){
    res.render('score',{score:quiz.totalCorrect,min:Math.floor(Number(quiz.time)/60),secs:Number(quiz.time)%60,id,sub});
    } else {
        res.redirect('/');
    }
    }catch(err){
        console.log(err);
    }
}

exports.getDetailed = async(req,res,next)=>{
    try{
        const {id,sub}=req.query;
        const user = await User.findById(req.session.user._id).populate('genralQuizes.questions.questionId');
        const report = user[`${sub}Quizes`].find(e=>e._id.toString() === id.toString())
        res.render('result',{report});
    }catch(err){
        console.log(err);
    }
};

exports.getTillDate = async(req,res,next)=>{
    try{
        const user = await User.findById(req.session.user._id);
        res.render('section',{s:user.genral[0]});
    }catch(err){
        console.log(err)
    }
}