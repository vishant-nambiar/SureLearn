function answer(user) {
    const answers = [];
    if (user.answer0) {
        answers.push({
            _id: user.id0,
            time: user.time0,
            answer: user.answer0
        })
    } else {
        answers.push({
            _id: user.id0,
            time: user.time0,
            answer: null
        })
    }
    if (user.answer1) {
        answers.push({
            _id: user.id1,
            time: user.time1,
            answer: user.answer1
        })
    } else {
        answers.push({
            _id: user.id1,
            time: user.time1,
            answer: null
        })
    }
    if (user.answer2) {
        answers.push({
            _id: user.id2,
            time: user.time2,
            answer: user.answer2
        })
    } else {
        answers.push({
            _id: user.id2,
            time: user.time2,
            answer: null
        })
    }
    if (user.answer3) {
        answers.push({
            _id: user.id3,
            time: user.time3,
            answer: user.answer3
        })
    } else {
        answers.push({
            _id: user.id3,
            time: user.time3,
            answer: null
        })
    }
    if (user.answer4) {
        answers.push({
            _id: user.id4,
            time: user.time4,
            answer: user.answer4
        })
    } else {
        answers.push({
            _id: user.id4,
            time: user.time4,
            answer: null
        })
    }
    if (user.answer5) {
        answers.push({
            _id: user.id5,
            time: user.time5,
            answer: user.answer5
        })
    } else {
        answers.push({
            _id: user.id5,
            time: user.time5,
            answer: null
        })
    }
    if (user.answer6) {
        answers.push({
            _id: user.id6,
            time: user.time6,
            answer: user.answer6
        })
    } else {
        answers.push({
            _id: user.id6,
            time: user.time6,
            answer: null
        })
    }
    if (user.answer7) {
        answers.push({
            _id: user.id7,
            time: user.time7,
            answer: user.answer7
        })
    } else {
        answers.push({
            _id: user.id7,
            time: user.time7,
            answer: null
        })
    }
    if (user.answer8) {
        answers.push({
            _id: user.id8,
            time: user.time8,
            answer: user.answer8
        })
    } else {
        answers.push({
            _id: user.id8,
            time: user.time8,
            answer: null
        })
    }
    if (user.answer9) {
        answers.push({
            _id: user.id9,
            time: user.time9,
            answer: user.answer9
        })
    } else {
        answers.push({
            _id: user.id9,
            time: user.time9,
            answer: null
        })
    }
    if (user.answer10) {
        answers.push({
            _id: user.id10,
            time: user.time10,
            answer: user.answer10
        })
    } else {
        answers.push({
            _id: user.id10,
            time: user.time10,
            answer: null
        })
    }
    if (user.answer11) {
        answers.push({
            _id: user.id11,
            time: user.time11,
            answer: user.answer11
        })
    } else {
        answers.push({
            _id: user.id11,
            time: user.time11,
            answer: null
        })
    }
    if (user.answer12) {
        answers.push({
            _id: user.id12,
            time: user.time12,
            answer: user.answer12
        })
    } else {
        answers.push({
            _id: user.id12,
            time: user.time12,
            answer: null
        })
    }
    if (user.answer13) {
        answers.push({
            _id: user.id13,
            time: user.time13,
            answer: user.answer13
        })
    } else {
        answers.push({
            _id: user.id13,
            time: user.time13,
            answer: null
        })
    }
    if (user.answer14) {
        answers.push({
            _id: user.id14,
            time: user.time14,
            answer: user.answer14
        })
    } else {
        answers.push({
            _id: user.id14,
            time: user.time14,
            answer: null
        })
    }
    if (user.answer15) {
        answers.push({
            _id: user.id15,
            time: user.time15,
            answer: user.answer15
        })
    } else {
        answers.push({
            _id: user.id15,
            time: user.time15,
            answer: null
        })
    }
    if (user.answer16) {
        answers.push({
            _id: user.id16,
            time: user.time16,
            answer: user.answer16
        })
    } else {
        answers.push({
            _id: user.id16,
            time: user.time16,
            answer: null
        })
    }
    if (user.answer17) {
        answers.push({
            _id: user.id17,
            time: user.time17,
            answer: user.answer17
        })
    } else {
        answers.push({
            _id: user.id17,
            time: user.time17,
            answer: null
        })
    }
    if (user.answer18) {
        answers.push({
            _id: user.id18,
            time: user.time18,
            answer: user.answer18
        })
    } else {
        answers.push({
            _id: user.id18,
            time: user.time18,
            answer: null
        })
    }
    if (user.answer19) {
        answers.push({
            _id: user.id19,
            time: user.time19,
            answer: user.answer19
        })
    } else {
        answers.push({
            _id: user.id19,
            time: user.time19,
            answer: null
        })
    }
    if (user.answer20) {
        answers.push({
            _id: user.id20,
            time: user.time20,
            answer: user.answer20
        })
    } else {
        answers.push({
            _id: user.id20,
            time: user.time20,
            answer: null
        })
    }
    if (user.answer21) {
        answers.push({
            _id: user.id21,
            time: user.time21,
            answer: user.answer21
        })
    } else {
        answers.push({
            _id: user.id21,
            time: user.time21,
            answer: null
        })
    }
    if (user.answer22) {
        answers.push({
            _id: user.id22,
            time: user.time22,
            answer: user.answer22
        })
    } else {
        answers.push({
            _id: user.id22,
            time: user.time22,
            answer: null
        })
    }
    if (user.answer23) {
        answers.push({
            _id: user.id23,
            time: user.time23,
            answer: user.answer23
        })
    } else {
        answers.push({
            _id: user.id23,
            time: user.time23,
            answer: null
        })
    }
    if (user.answer24) {
        answers.push({
            _id: user.id24,
            time: user.time24,
            answer: user.answer24
        })
    } else {
        answers.push({
            _id: user.id24,
            time: user.time24,
            answer: null
        })
    }
    if (user.answer25) {
        answers.push({
            _id: user.id25,
            time: user.time25,
            answer: user.answer25
        })
    } else {
        answers.push({
            _id: user.id25,
            time: user.time25,
            answer: null
        })
    }
    if (user.answer26) {
        answers.push({
            _id: user.id26,
            time: user.time26,
            answer: user.answer26
        })
    } else {
        answers.push({
            _id: user.id26,
            time: user.time26,
            answer: null
        })
    }
    if (user.answer27) {
        answers.push({
            _id: user.id27,
            time: user.time27,
            answer: user.answer27
        })
    } else {
        answers.push({
            _id: user.id27,
            time: user.time27,
            answer: null
        })
    }
    if (user.answer28) {
        answers.push({
            _id: user.id28,
            time: user.time28,
            answer: user.answer28
        })
    } else {
        answers.push({
            _id: user.id28,
            time: user.time28,
            answer: null
        })
    }
    if (user.answer29) {
        answers.push({
            _id: user.id29,
            time: user.time29,
            answer: user.answer29
        })
    } else {
        answers.push({
            _id: user.id29,
            time: user.time29,
            answer: null
        })
    }
    return answers;
}

module.exports = answer;