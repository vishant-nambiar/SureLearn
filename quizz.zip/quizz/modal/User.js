const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const userSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    genral: {
        type: Array
    },
    genralQuizes: [{
        questions: [{
            questionId: {
                type: Schema.Types.ObjectId,
                ref: 'Genral',
                required: true
            },
            time: {
                type: Number
            },
            userChoice: {
                type: String
            }
        }],
        totalCorrect: Number,
        time: Number,
        subject: String
    }]
}, { timestamps: true })

module.exports = mongoose.model('User', userSchema);