const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const genralSchema = new Schema({
    Question: {
        type: String,
        required: true
    },
    Option_A: {
        type: String
    },
    Option_B: {
        type: String
    },
    Option_C: {
        type: String
    },
    Option_D: {
        type: String
    },
    Option_E: {
        type: String
    },
    Answer: {
        type: String,
        required: true
    },
    Section: {
        type: String,
        required: true
    },
    averageSolvingTime: {
        type: Number
    },
    users: {
        userIds: [{
            userId: {
                type: Schema.Types.ObjectId,
                ref: 'User'
            }
        }]
    },
    minimumTime: {
        type: Number
    }
}, { timestamps: true });

module.exports = mongoose.model('Genral', genralSchema);