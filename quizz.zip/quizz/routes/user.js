const express = require('express');

const router = express.Router();

const quizController = require('../controller/quiz');
const userController = require('../controller/user');
const isAuth = require('../middleware/is-auth');

router.get('/login', userController.getLogin);
router.post('/login', userController.postLogin);
router.post('/register', userController.postRegister);
router.get('/', isAuth, userController.getTake);
router.get('/quiz', isAuth, quizController.getQuiz);
router.post('/submit', isAuth, quizController.postQuiz);
router.get('/result', isAuth, quizController.getResult);
router.get('/details', isAuth, quizController.getDetailed);
router.get('/section', isAuth, quizController.getTillDate);

module.exports = router;